# Microphone fix for GM 9 Pro Device

**This module is useless if you don't have GM 9 Pro Device**

This module reconfigures dual microphones on GM 9 Pro device by editing /vendor/etc/mixer_paths.xml DO NOT INSTALL ON OTHER DEVICES.

## Requirements
- GM 9 Pro with non-beta rom

## Changelog
- v1.0 inital release
